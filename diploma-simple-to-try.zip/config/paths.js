const path = require('path')

module.exports = {
    // Source
    src: path.resolve(__dirname, '../src'),

    // Production build
    build: path.resolve(__dirname, '../build'),
}
