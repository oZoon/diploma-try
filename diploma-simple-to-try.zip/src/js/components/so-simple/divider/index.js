import React from "react";
import './divider.css';

export default () => <span className="divider"></span>
